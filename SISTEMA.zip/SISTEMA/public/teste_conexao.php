<?php
// ATIVA A EXIBIÇÃO DE TODOS OS ERROS POSSÍVEIS.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Teste de Conexão com Banco de Dados</h1>";

// --- PREENCHA SUAS CREDENCIAIS AQUI ---
// Copie e cole CADA UMA delas DIRETAMENTE do cPanel para evitar erros.

$servidor   = "localhost";
$usuario_db = "kareng52_wp686"; // Ex: seusite_user
$senha_db   = "Sistema@01";            // A senha que você redefiniu
$banco      = "kareng52_wp686";    // Ex: seusite_dados

// --- FIM DA ÁREA DE PREENCHIMENTO ---

echo "<p>Tentando conectar ao servidor: " . $servidor . "...</p>";
echo "<p>Usuário: " . $usuario_db . "</p>";
echo "<p>Banco de Dados: " . $banco . "</p>";
echo "<hr>";

// Tenta criar a conexão com o banco de dados
$conexao = new mysqli($servidor, $usuario_db, $senha_db, $banco);

// Verifica o resultado da conexão
if ($conexao->connect_error) {
    // Se houver um erro, o script para e mostra a mensagem de erro exata do servidor.
    echo "<h2>FALHA NA CONEXÃO!</h2>";
    echo "<p style='color:red; font-weight:bold;'>Erro: " . $conexao->connect_error . "</p>";
} else {
    // Se a conexão for bem-sucedida, mostra uma mensagem de sucesso.
    echo "<h2>SUCESSO!</h2>";
    echo "<p style='color:green; font-weight:bold;'>Conexão com o banco de dados '" . $banco . "' foi estabelecida com sucesso!</p>";
    
    // Fecha a conexão
    $conexao->close();
}
?>